# Project TAU — Student Registry MVP

A small mobile-friendly registration application for collecting each student's full
name and matriculation number into Neon PostgreSQL. The pilot department is fixed
through `PILOT_DEPARTMENT`; students do not choose a department.

## Scope

- Public student registration form.
- Server-side validation and matric-number normalization.
- Database uniqueness constraint to prevent duplicate matric submissions.
- HTTP Basic protected administrator registry.
- CSV export.
- Records begin as `PENDING`; submission is not identity verification.

## Local setup

1. Create a Neon PostgreSQL database.
2. Copy `.env.example` to `.env` and fill in the values.
3. Create a virtual environment and install dependencies:

   ```bash
   python -m venv .venv
   source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
   pip install -r requirements.txt
   ```

4. For this MVP, initialize the table once using the explicit bootstrap command:

   ```bash
   python -m app.init_db
   ```

5. Start the server:

   ```bash
   uvicorn app.main:app --reload
   ```

6. Open `http://127.0.0.1:8000/`. The admin page is at `/admin`.

## Deployment

Render build command:

```bash
pip install -r requirements.txt
```

Render start command:

```bash
uvicorn app.main:app --host 0.0.0.0 --port $PORT
```

Set all `.env` values in the Render environment dashboard. Use HTTPS. Never commit
`.env` or share the admin password.

## Database note

The bootstrap command creates the initial table for this small MVP. Before adding
schema changes or expanding the application, introduce Alembic migrations and
manage all subsequent schema changes through migrations. Do not run table creation
automatically on application startup.

## Operational safeguards before public launch

- Set a strong, unique administrator password.
- Confirm the collection purpose, privacy notice, authorized users and retention
  period with the department.
- Share the registration URL only with the intended student cohort.
- Configure host-level rate limiting/WAF protection before broad public exposure.
- Verify the roster against an authoritative departmental list before marking
  entries `VERIFIED`.
- Back up the Neon database and restrict database credentials.
- Do not treat student-entered data as verified identity.

## Current limitations

- No student login or self-service correction flow.
- No automated official-roster matching.
- No admin edit/verification workflow yet.
- HTTP Basic is used for the small initial admin page; deploy only behind HTTPS.
- The honeypot is basic bot friction, not a substitute for rate limiting.
